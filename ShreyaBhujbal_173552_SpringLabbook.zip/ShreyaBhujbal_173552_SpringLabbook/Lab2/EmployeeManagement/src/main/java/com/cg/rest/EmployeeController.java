/**
 * 
 */
package com.cg.rest;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.cg.entity.Employee;
import com.cg.service.EmployeeService;

/**
 * This is Controller class for Employee
 * 
 * @author sbhujbal
 *
 */
@RestController
public class EmployeeController {

	@Autowired
	EmployeeService service;

	/**
	 * Create This is use to insert given data into database for creating required
	 * records by using specified path
	 * 
	 * @param e
	 * @return
	 */
	@PostMapping(path = "/create", consumes = "application/json")
	public String create(@RequestBody Employee e) {
		service.saveEmployee(e);
		return "Record is Saved";

	}

	/**
	 * Get All This is gives list of all employee record inserted into table by
	 * using specified path
	 * 
	 * @return
	 */
	@GetMapping(path = "/employees", produces = "application/json")
	public Iterable<Employee> view() {
		return service.getAllEmployee();
	}

	/**
	 * Update by Id This is used to update the records with the help of id by using
	 * specified path
	 * 
	 * @param empId
	 * @param e
	 * @return
	 */
	@PutMapping(path = "/updateemployee/{empId}", consumes = "application/json")
	public Employee updateAlbum(@PathVariable("empId") int empId, @RequestBody Employee e) {
		return service.updateEmployee(e, empId);

	}

	/**
	 * Get by Id This is used to get record by Id
	 * 
	 * @param empId
	 * @return
	 */
	@GetMapping(path = "/getbyId/{empId}", produces = "application/json")
	public ResponseEntity<Employee> getbyId(@PathVariable("empId") int empId) {
		try {
			Employee e = service.getEmployee(empId);
			return new ResponseEntity<Employee>(e, HttpStatus.OK);
		} catch (NoSuchElementException e) {
			return new ResponseEntity(e.getMessage(), HttpStatus.NOT_FOUND);
		}
	}

	/**
	 * Get by department name This is used to get record by department name
	 * 
	 * @param departmentName
	 * @return
	 */

	/*@GetMapping(path = "/employees/{departmentName}", produces = "application/json")
	public Employee getbyName(@PathVariable("departmentName") String departmentName) {
		Employee a = service.getEmployeeByDepartment(departmentName);
		return a;
	}*/

	/**
	 * Delete by Id This is used to delete record from table
	 * 
	 * @param empId
	 * @return
	 */

	@DeleteMapping(path = "/delete/{empId}")
	public String delete(@PathVariable("empId" + "") int empId) {
		service.deleteEmployee(empId);
		return "Record deleted";
	}

}
