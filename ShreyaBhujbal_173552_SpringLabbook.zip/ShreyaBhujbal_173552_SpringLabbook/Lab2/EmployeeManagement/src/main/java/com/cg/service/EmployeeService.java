/**
 * 
 */
package com.cg.service;


import com.cg.entity.Employee;

/**
 * This is the service interface for Employee
 * 
 * @author sbhujbal
 *
 */
public interface EmployeeService {

	void saveEmployee(Employee e);

	Employee getEmployee(int empId);

	Iterable<Employee> getAllEmployee();

	public String deleteEmployee(int empId);

	public Employee updateEmployee(Employee e, int empId);
	Employee getEmployeeByDepartment(String departmentName);

}
