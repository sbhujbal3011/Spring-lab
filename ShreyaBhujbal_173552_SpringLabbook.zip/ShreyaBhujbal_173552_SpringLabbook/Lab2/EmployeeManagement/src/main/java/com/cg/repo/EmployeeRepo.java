/**
 * 
 */
package com.cg.repo;

import org.springframework.data.repository.CrudRepository;


import com.cg.entity.Employee;

/**This is Repo interface for employee 
 * @author sbhujbal
 *
 */
public interface EmployeeRepo extends CrudRepository<Employee, Integer> {
	Employee findBydepartmentName(String departmentName);

}
