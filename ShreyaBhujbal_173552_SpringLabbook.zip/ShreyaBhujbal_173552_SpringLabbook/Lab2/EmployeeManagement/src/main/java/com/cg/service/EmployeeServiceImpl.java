/**
 * 
 */
package com.cg.service;

import java.util.NoSuchElementException;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;


import com.cg.entity.Employee;
import com.cg.repo.EmployeeRepo;

/**
 * This is the service implementation of employee
 * 
 * @author sbhujbal
 *
 */

@Repository
public class EmployeeServiceImpl implements EmployeeService {

	@Autowired
	private EmployeeRepo repo;

	@Transactional(propagation = Propagation.REQUIRED)
	public void saveEmployee(Employee e) {
		repo.save(e);

	}

	/*@Transactional(propagation = Propagation.SUPPORTS)
	public Employee getEmployee(int empId) {
		return repo.findById(empId).get();

	}*/
	@Transactional(propagation = Propagation.SUPPORTS)
	public Employee getEmployee(int empId)throws NoSuchElementException {
		try {
			return repo.findById(empId).get();
		} catch (Exception e) {
			throw new NoSuchElementException("id not found");
		}
	}
	@Transactional
	public Iterable<Employee> getAllEmployee() {
		return repo.findAll();
	}

	@Transactional
	public String deleteEmployee(int empId) {
		Employee e1 = repo.findById(empId).get();
		repo.delete(e1);
		return "Record Deleted";
	}

	@Transactional
	public Employee updateEmployee(Employee e, int empId) {
		e.setEmpId(empId);
		repo.save(e);
		return e;
	}

	@Transactional
	public Employee getEmployeeByDepartment(String departmentName) {
		
		return repo.findBydepartmentName(departmentName);
	}

}
