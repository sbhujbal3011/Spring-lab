/**This is repo interface
 * @author sbhujbal
 */
package com.cg.repo;

import java.util.List;

import com.cg.entity.ProductDetails;

public interface ProductDetailsRepo {
	
	ProductDetails saveProduct(ProductDetails p);

	ProductDetails get(int id);

	List<ProductDetails> getAll();
}
