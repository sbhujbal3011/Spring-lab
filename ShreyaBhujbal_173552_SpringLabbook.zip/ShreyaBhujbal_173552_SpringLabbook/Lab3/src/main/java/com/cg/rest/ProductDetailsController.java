/**This 
 * @author sbhujbal
 */

package com.cg.rest;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.ModelAndView;

import com.cg.entity.ProductDetails;

import com.cg.repo.ProductDetailsRepo;

@RestController
@RequestMapping("api/v1")
public class ProductDetailsController {

	@Autowired
	private ProductDetailsRepo repo;

	/**
	 * For homepage
	 * @param model
	 * @return
	 */
	@GetMapping("/homepage")
	public ModelAndView homePage(Model model) {
		return new ModelAndView("product", "product", new ProductDetails());

	}
	/**
	 * for addproduct
	 * @param productDetails
	 * @param model
	 * @return
	 */

	@PostMapping("/add")
	public ProductDetails addProduct(@ModelAttribute("product") ProductDetails productDetails, Model model) {
		productDetails = repo.saveProduct(productDetails);
		model.addAttribute("result", "Added Successfully");
		return productDetails;

	}

	@GetMapping(path = "/products", produces = "application/json")
	public List<ProductDetails> showAllProduct() {
		return repo.getAll();
	}

	@ExceptionHandler({ java.sql.SQLIntegrityConstraintViolationException.class,
			org.springframework.web.util.NestedServletException.class,
			org.springframework.orm.jpa.JpaSystemException.class, javax.persistence.PersistenceException.class,
			org.hibernate.exception.ConstraintViolationException.class })

	public ModelAndView showError(Model model) {
		return new ModelAndView("error");

	}

}