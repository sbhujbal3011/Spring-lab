package com.cg.repo;

import java.util.List;

import javax.persistence.EntityManager;
import javax.persistence.PersistenceContext;

import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import com.cg.entity.ProductDetails;

@Repository

public class ProductDetailsRepoImpl implements ProductDetailsRepo {
	@PersistenceContext(unitName = "SpringJPA")
	private EntityManager em;

	@Transactional(propagation = Propagation.REQUIRED) 
	public ProductDetails saveProduct(ProductDetails p) {
	
		em.persist(p);
		return p;

	}

	@Transactional(propagation = Propagation.SUPPORTS) 
	public ProductDetails get(int id) {
		return em.find(ProductDetails.class, id);

	}

	@Transactional
	public List<ProductDetails> getAll() {
		return em.createQuery("from Product").getResultList();
	}

}
