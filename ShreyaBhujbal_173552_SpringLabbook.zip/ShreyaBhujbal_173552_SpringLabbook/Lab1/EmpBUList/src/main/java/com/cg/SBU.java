/**
 * 
 */
package com.cg;

import java.util.List;

/**
 * @author sbhujbal
 *
 */
public class SBU {
	private int sbuCode;
	private String sbuName;
	private String sbuHead;
	private List<Employee> emplist;
	Employee employee;

	/**
	 * 
	 */
	public SBU() {
		super();
		// TODO Auto-generated constructor stub
	}

	/**
	 * @param sbuCode
	 * @param sbuName
	 * @param sbuHead
	 * @param emplist
	 */
	public SBU(int sbuCode, String sbuName, String sbuHead, List<Employee> emplist) {
		super();
		this.sbuCode = sbuCode;
		this.sbuName = sbuName;
		this.sbuHead = sbuHead;
		this.emplist = emplist;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "SBU [sbuCode=" + sbuCode + ", sbuName=" + sbuName + ", sbuHead=" + sbuHead + ", emplist=" + emplist
				+ "]";
	}

	/**
	 * @return the sbuCode
	 */
	public int getSbuCode() {
		return sbuCode;
	}

	/**
	 * @param sbuCode
	 *            the sbuCode to set
	 */
	public void setSbuCode(int sbuCode) {
		this.sbuCode = sbuCode;
	}

	/**
	 * @return the sbuName
	 */
	public String getSbuName() {
		return sbuName;
	}

	/**
	 * @param sbuName
	 *            the sbuName to set
	 */
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}

	/**
	 * @return the sbuHead
	 */
	public String getSbuHead() {
		return sbuHead;
	}

	/**
	 * @param sbuHead
	 *            the sbuHead to set
	 */
	public void setSbuHead(String sbuHead) {
		this.sbuHead = sbuHead;
	}

	/**
	 * @return the emplist
	 */
	public List<Employee> getEmplist() {
		return emplist;
	}

	/**
	 * @param emplist
	 *            the emplist to set
	 */
	public void setEmplist(List<Employee> emplist) {
		this.emplist = emplist;
	}

}
