/**
 * 
 */
package com.cg.test;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;

import com.cg.entity.Employee;
import com.cg.entity.SBU;

/**
 * @author sbhujbal
 *
 */
public class TestEmpBu {
	@Test
	public void Test() {
		ApplicationContext emp = new ClassPathXmlApplicationContext("emp.xml");
		Employee e = emp.getBean(Employee.class);
		
		System.out.println(e);
		assertNotNull(e);
	}

}
