/**
 * 
 */
package com.cg.entity;

/**
 * This is entity for employee
 * 
 * @author sbhujbal
 *
 */
public class Employee {

	private String empId;
	private String empName;
	private double empSalary;
	
	private int empAge;
	private SBU BU;
	
	public Employee() {
		
	}
	
	/**
	 * @return the empId
	 */
	public String getEmpId() {
		return empId;
	}
	/**
	 * @param empId the empId to set
	 */
	public void setEmpId(String empId) {
		this.empId = empId;
	}
	/**
	 * @return the empName
	 */
	public String getEmpName() {
		return empName;
	}
	/**
	 * @param empName the empName to set
	 */
	public void setEmpName(String empName) {
		this.empName = empName;
	}
	/**
	 * @return the empSalary
	 */
	public double getEmpSalary() {
		return empSalary;
	}
	/**
	 * @param empSalary the empSalary to set
	 */
	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}
	/**
	 * @return the empAge
	 */
	public int getEmpAge() {
		return empAge;
	}
	/**
	 * @param empAge the empAge to set
	 */
	public void setEmpAge(int empAge) {
		this.empAge = empAge;
	}
	/**
	 * @return the bU
	 */
	public SBU getBU() {
		return BU;
	}
	/**
	 * @param bU the bU to set
	 */
	public void setBU(SBU bU) {
		BU = bU;
	}
	/* (non-Javadoc)
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", empAge=" + empAge
				+ ", BU=" + BU + "]";
	}
	/**
	 * @param empId
	 * @param empName
	 * @param empSalary
	 * @param empAge
	 * @param bU
	 */
	public Employee(String empId, String empName, double empSalary, int empAge, SBU bU) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
		this.empAge = empAge;
		this.BU = bU;
	}
	

}