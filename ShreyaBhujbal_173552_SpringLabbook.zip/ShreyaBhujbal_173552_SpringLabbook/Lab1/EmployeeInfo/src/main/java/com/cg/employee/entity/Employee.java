package com.cg.employee.entity;

/**
 * This is the bean entity for employeeInfo
 * 
 * @author sbhujbal
 *
 */

public class Employee {

	private String empId;
	private String empName;
	private double empSalary;
	private String empBU;
	private int empAge;

	public Employee(String empId, String empName, double empSalary, String empBU, int empAge) {
		super();
		this.empId = empId;
		this.empName = empName;
		this.empSalary = empSalary;
		this.empBU = empBU;
		this.empAge = empAge;
	}

	/**
	 * @return the empId
	 */
	public String getEmpId() {
		return empId;
	}

	

	/**
	 * @param empId
	 *            the empId to set
	 */
	public void setEmpId(String empId) {
		this.empId = empId;
	}

	/**
	 * @return the empName
	 */
	public String getEmpName() {
		return empName;
	}

	/**
	 * @param empName
	 *            the empName to set
	 */
	public void setEmpName(String empName) {
		this.empName = empName;
	}

	/**
	 * @return the empSalary
	 */
	public double getEmpSalary() {
		return empSalary;
	}

	/**
	 * @param empSalary
	 *            the empSalary to set
	 */
	public void setEmpSalary(double empSalary) {
		this.empSalary = empSalary;
	}

	/**
	 * @return the empBU
	 */
	public String getEmpBU() {
		return empBU;
	}

	/**
	 * @param empBU
	 *            the empBU to set
	 */
	public void setEmpBU(String empBU) {
		this.empBU = empBU;
	}

	/**
	 * @return the empAge
	 */
	public int getEmpAge() {
		return empAge;
	}

	/**
	 * @param empAge
	 *            the empAge to set
	 */
	public void setEmpAge(int empAge) {
		this.empAge = empAge;
	}
	@Override
	public String toString() {
		return "Employee [empId=" + empId + ", empName=" + empName + ", empSalary=" + empSalary + ", empBU=" + empBU
				+ ", empAge=" + empAge + "]";
	}

}
