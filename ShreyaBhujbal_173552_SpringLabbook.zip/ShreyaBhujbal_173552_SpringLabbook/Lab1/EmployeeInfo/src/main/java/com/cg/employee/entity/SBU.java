/**
 * 
 */
package com.cg.employee.entity;

/**
 * @author sbhujbal
 *
 */
public class SBU {

	private String sbuId;
	private String sbuName;
	private double sbuHead;

	/**
	 * @return the sbuId
	 */
	public String getSbuId() {
		return sbuId;
	}

	/**
	 * @param sbuId
	 *            the sbuId to set
	 */
	public void setSbuId(String sbuId) {
		this.sbuId = sbuId;
	}

	/**
	 * @param sbuId
	 * @param sbuName
	 * @param sbuHead
	 */
	public SBU(String sbuId, String sbuName, double sbuHead) {
		super();
		this.sbuId = sbuId;
		this.sbuName = sbuName;
		this.sbuHead = sbuHead;
	}

	/*
	 * (non-Javadoc)
	 * 
	 * @see java.lang.Object#toString()
	 */
	@Override
	public String toString() {
		return "SBU [sbuId=" + sbuId + ", sbuName=" + sbuName + ", sbuHead=" + sbuHead + "]";
	}

	/**
	 * @return the sbuName
	 */
	public String getSbuName() {
		return sbuName;
	}

	/**
	 * @param sbuName
	 *            the sbuName to set
	 */
	public void setSbuName(String sbuName) {
		this.sbuName = sbuName;
	}

	/**
	 * @return the sbuHead
	 */
	public double getSbuHead() {
		return sbuHead;
	}

	/**
	 * @param sbuHead
	 *            the sbuHead to set
	 */
	public void setSbuHead(double sbuHead) {
		this.sbuHead = sbuHead;
	}

}
