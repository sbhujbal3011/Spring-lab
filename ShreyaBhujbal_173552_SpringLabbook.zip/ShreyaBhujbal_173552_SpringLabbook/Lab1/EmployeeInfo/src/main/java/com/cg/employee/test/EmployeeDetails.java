
package com.cg.employee.test;

import static org.junit.Assert.assertNotNull;

import org.junit.Test;
import org.springframework.beans.factory.BeanFactory;
import org.springframework.beans.factory.xml.XmlBeanFactory;
import org.springframework.context.ApplicationContext;
import org.springframework.context.support.ClassPathXmlApplicationContext;
import org.springframework.core.io.ClassPathResource;
import org.springframework.core.io.Resource;

import com.cg.employee.entity.Employee;

/**
 * @author sbhujbal
 *
 */

public class EmployeeDetails {
	
	@Test
	public void Test() {
	ApplicationContext emp=new ClassPathXmlApplicationContext("emp.xml");
	Employee e= emp.getBean(Employee.class);
	System.out.println("Employee Details");
	System.out.println("Employee ID:" +e.getEmpId());
	System.out.println("Employee Name:" +e.getEmpName());
	System.out.println("Employee salary:" +e.getEmpSalary());
	System.out.println("Employee BU:" +e.getEmpBU());
	System.out.println("Employee Age:"+e.getEmpAge());
	assertNotNull(e);
	}

	

}
